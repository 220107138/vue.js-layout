import { createRouter, createWebHistory } from 'vue-router';
import { createApp } from 'vue';
import App from './App.vue';

import Dashboard from './components/views/Dashboard.vue';
import Project from './components/views/Project.vue';

const router = createRouter({
    history: createWebHistory(),
    routes: [
      { path: '/', component: Dashboard },
      { path: '/project', component: Project}
    ],
  });
  
  createApp(App).use(router).mount('#app');